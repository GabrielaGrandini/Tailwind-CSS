package com.devsenai2A.gabriela.petshop.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "produto")
public class Produto {
	
	@Id()
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idProduto;
	
	public Produto () {
		
	}
	
	private String nome;
	private String descricao;
	private double preco;
	private double preco_desconto;
	private int qtd_estoque;
	private boolean ativo;
	@ManyToOne
	@JoinColumn(name="id_categoria")
	private Categoria categoria;
	public Long getIdProduto() {
		return idProduto;
	}
	
	


	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	public double getPreco_desconto() {
		return preco_desconto;
	}

	public void setPreco_desconto(double preco_desconto) {
		this.preco_desconto = preco_desconto;
	}

	public int getQtd_estoque() {
		return qtd_estoque;
	}

	public void setQtd_estoque(int qtd_estoque) {
		this.qtd_estoque = qtd_estoque;
	}

	public boolean isAtivo() {
		return ativo;
	}

	public void setAtivo(boolean ativo) {
		this.ativo = ativo;
	}

	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}

	public void setIdProduto(Long idProduto) {
		this.idProduto = idProduto;
	}

	@Column(columnDefinition = "LONGTEXT")
	private String img;
	
	public String getImg() {
		return img;
	}
	
	public void setImg(String img) {
		this.img = img;
	}
}
