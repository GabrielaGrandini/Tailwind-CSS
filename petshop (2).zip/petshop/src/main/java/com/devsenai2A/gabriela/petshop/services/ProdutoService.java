package com.devsenai2A.gabriela.petshop.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.devsenai2A.gabriela.petshop.entities.Categoria;
import com.devsenai2A.gabriela.petshop.entities.Produto;
import com.devsenai2A.gabriela.petshop.repositories.CategoriaRepository;
import com.devsenai2A.gabriela.petshop.repositories.ProdutoRepository;

@Service
public class ProdutoService {
	
	@Autowired
    private ProdutoRepository ProdutoRepository;
	
    @Autowired
    private CategoriaRepository CategoriaRepository;
	
	private final ProdutoRepository repository;
	
	public ProdutoService(ProdutoRepository repository) {
		this.repository = repository;
	}
	
	public Produto criar(Produto produto) {
		return repository.save(produto);
	}
	
	public List<Produto> findAll(){
		return repository.findAll();
	}
	
	public Produto atualizar(Long id, Produto dados) {
		Produto produto = repository.findById(id).orElse(null);
		if(produto == null) {
			return null;
		}
		
		produto.setNome(dados.getNome());
		produto.setDescricao(dados.getDescricao());
		produto.setPreco(dados.getPreco());
		produto.setPreco_desconto(dados.getPreco_desconto());
		produto.setQtd_estoque(dados.getQtd_estoque());
		produto.setImg(dados.getImg());
		produto.setAtivo(true); 
		
	    Categoria categoria = CategoriaRepository.findById(dados.getCategoria().getIdCategoria())
	            .orElseThrow(() -> new RuntimeException("Categoria não encontrada"));
		produto.setCategoria(categoria);
		
        return ProdutoRepository.save(produto);
	}
	
	
	public boolean deletar(Long id) {
		if(!repository.existsById(id)) {
			return false;
		}
		
		repository.deleteById(id);
		return true;
	}
	
	public Produto buscarPorId(Long id) {
		return repository.findById(id).orElse(null);
	}
	
}
