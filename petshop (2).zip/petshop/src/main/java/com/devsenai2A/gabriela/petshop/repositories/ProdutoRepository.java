package com.devsenai2A.gabriela.petshop.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import com.devsenai2A.gabriela.petshop.entities.Produto;


public interface ProdutoRepository extends JpaRepository<Produto, Long> {
	
	Produto findByNome(String nome);

}
