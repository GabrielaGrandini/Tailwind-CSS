package com.devsenai2A.gabriela.petshop.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.devsenai2A.gabriela.petshop.entities.Produto;
import com.devsenai2A.gabriela.petshop.services.ProdutoService;

@RestController
@RequestMapping("/api/produtos")
public class ProdutoController {
	
	@Autowired
	private ProdutoService service;
	
	@PostMapping
	public ResponseEntity <Produto> criarProduto(@RequestBody Produto produto) {
		Produto novoProduto = service.criar(produto);
		return ResponseEntity.status(HttpStatus.CREATED).body(novoProduto);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deletarProduto(@PathVariable Long id) {
		
		boolean removido = service.deletar(id);
		
		if(!removido) {
			return ResponseEntity.notFound().build();
		}
		
		return ResponseEntity.noContent().build();
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Produto> atualizarProduto(
			@PathVariable Long id,
			@RequestBody Produto produto){
		
		Produto produtoAtualizado = service.atualizar(id,produto);
		
		if(produtoAtualizado  == null) {
			return ResponseEntity.notFound().build();
		}
		
		return ResponseEntity.ok(produtoAtualizado );
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Produto> buscarPorId(@PathVariable Long id) {
		Produto produto = service.buscarPorId(id);
		if(produto == null) return ResponseEntity.notFound().build();
		return ResponseEntity.ok(produto);
	}
	
	@GetMapping 
	public List<Produto>listarCategorias(){
		return service.findAll();
	}

}